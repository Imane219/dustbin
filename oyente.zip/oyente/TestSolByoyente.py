#!/usr/bin/env python3
import subprocess
import os
import shutil
from openpyxl import Workbook
import re

g_sol_bug_type = 'reentrancy'
g_sol_dir_path = '/home/lce/download/oyente1/test/GNNbugsol/' + g_sol_bug_type + '/'#sol文件路径
g_oyente_dir_path = '/home/lce/download/oyente1/test/GNNbugsol/'#好像没什么用
g_excel_path = '/home/lce/download/oyente1/test/GNNbugsol/reentrancy.xlsx'#excel表格路径
g_cmd_path = '/home/lce/download/oyente1/oyente/'#cmd执行路径（oyente.py所在文件夹）

i = 2

def main():
    excel = Workbook()
    sheet = excel.active
    sheet['A1'] = 'Contract Name'
    sheet['B1'] = 'Coverage'
    sheet['C1'] = 'reentrancy'
    sheet['D1'] = 'timestamp'
    sheet['E1'] = 'Not Test'

    global i
    files = os.listdir(g_sol_dir_path)#返回文件夹中文件名字列表
    if not files:
        print('No file!')
        return
    #oyente_sol_dir_path = g_oyente_dir_path + 'contracts/'
    os.chdir(g_cmd_path)#类似于cd g_oyente_dir_path
    for file in files:
        #make_dir(oyente_sol_dir_path)
        #shutil.copy(g_sol_dir_path+file, oyente_sol_dir_path)#把源文件拷贝到contracts文件夹中
        test_sol(sheet, file)
        i += 1
    # print(test_info[1])
    excel.save(g_excel_path)


def copy_dir(src_dir_path, dest_dir_path):
    if os.path.exists(dest_dir_path):
        shutil.rmtree(dest_dir_path)
    shutil.copytree(src_dir_path, dest_dir_path)


def make_dir(dir_path):
    if os.path.exists(dir_path):
        shutil.rmtree(dir_path)
    os.mkdir(dir_path)


def test_sol(sheet, file):
    global i
    test_info = None
    f = open('../test/GNNbugsol/' + g_sol_bug_type + '/' + file)
    file_info = f.read()
    solidity_version = re.search(r'pragma solidity \^(.+);', file_info)
    print('Start running')
    try:#按照字符串的命令执行,返回一个元组(a,b),a是执行状态,b是执行结果(字符串)
        if not solidity_version:#有的库文件没有版本号
            subprocess.getstatusoutput('solc use 0.4.18')
        else:
            subprocess.getstatusoutput('solc use ' + solidity_version.group(1))
        test_info = subprocess.getstatusoutput('chmod +x oyente.py && python3 oyente.py -s ../test/GNNbugsol/' + g_sol_bug_type + '/' + file + ' -ce')
    except:
        return False
    print(test_info[1])#输出结果
    #开始进行字符串匹配
    info = re.split(r'INFO:root:contract ',test_info[1])#split分开各个合约
    for each_contract in info[1:]:
        contract_name_info = re.search(r'../test/GNNbugsol/' + g_sol_bug_type+ '/(.+):', each_contract)#找到一个则返回，失败返回none，可以从字符串中间开始扫描
        coverage_info = re.search(r'EVM Code Coverage:\s+(.+)\s+', each_contract)
        reentrancy_info = re.search(r'Re-Entrancy Vulnerability:\s+(.+)\s+', each_contract)
        timestamp_info = re.search(r'Timestamp Dependency:\s+(.+)\s+', each_contract)
        if not contract_name_info:
            print('error')
            return False
        contract_name = contract_name_info.group(1)#返回匹配的第一个括号对应的部分
        if not reentrancy_info:
            reentrancy = 0
            sheet[f'E{i}'] = 1
        elif reentrancy_info.group(1) == 'True':
            reentrancy = 1
        else:
            reentrancy = 0
        if not timestamp_info:
            timestamp = 0
        elif timestamp_info.group(1) == 'True':
            timestamp = 1
        else:
            timestamp = 0
        if not coverage_info:
            coverage = 0
        else:
            coverage = coverage_info.group(1)

        print(contract_name, reentrancy, timestamp)
        sheet[f'A{i}'] = contract_name
        sheet[f'B{i}'] = coverage
        sheet[f'C{i}'] = reentrancy
        sheet[f'D{i}'] = timestamp
        i += 1


main()
