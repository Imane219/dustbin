module ApplicationHelper
  include ByteCodeHelper
  include SourceCodeHelper
end
